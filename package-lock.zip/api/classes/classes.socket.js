// Classes Socket
// ./api/classes/classes.socket.js
