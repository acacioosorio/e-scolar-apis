// Exams Controller
// ./api/exams/exams.controller.js
