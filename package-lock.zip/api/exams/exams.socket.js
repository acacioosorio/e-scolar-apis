// Exams Socket
// ./api/exams/exams.socket.js
