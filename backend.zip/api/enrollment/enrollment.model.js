// Enrollment Model
// ./api/enrollment/enrollment.model.js

const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const bcrypt = require('bcryptjs');
mongoose.Promise = global.Promise;

const EnrollmentSchema = new Schema({
    school: {
        type: Schema.Types.ObjectId,
        ref: "School",
        required: true,
    },
	student: {
		type: Schema.Types.ObjectId,
		ref: "Student",
		required: [true, "Please add a student"],
    },
    class: {
        type: Schema.Types.ObjectId,
        ref: "Class",
        required: [true, "Please add a class"],
    },
    academicYear: { type: Number, required: true },
    enrollmentDate: { type: Date, required: true },
    rollNumber: { type: String },
    status: {
        type: String,
        enum: ['studying', 'approved', 'failed', 'transferred', 'withdrawn'],
        default: 'studying',
    },
    finalGrade: { type: Number },
    documents: [
        {
            name: String,
            url: String,
        }
    ],
    generalObservations: String,
}, { timestamps: true })


EnrollmentSchema.index({ student: 1, class: 1 }, { unique: true });
EnrollmentSchema.index({ student: 1, academicYear: 1 }, { unique: true });
EnrollmentSchema.index({ class: 1 });

module.exports = mongoose.model("Enrollment", EnrollmentSchema);