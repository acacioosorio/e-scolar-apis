// Exams Router
// ./api/exams/index.js
