// Attendance Model
// ./api/attendance/attendance.model.js

const mongoose = require('mongoose');
