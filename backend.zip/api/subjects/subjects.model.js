// Subjects Model
// ./api/subjects/subjects.model.js

const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const bcrypt = require('bcryptjs');
mongoose.Promise = global.Promise;

const SubjectSchema = new Schema(
	{
		school: {
			type: Schema.Types.ObjectId,
			ref: "School",
			required: [true, "School is required"],
		},
		// Ex: "Matemática", "Português", "Inglês"
		name: {
			type: String,
			required: [true, "Please add a Subject name"],
		},
		code: {
			type: String,
		},
		academicYear: {
			type: Schema.Types.ObjectId,
			ref: "AcademicYear",
		},
		yearLevel: {
			type: Schema.Types.ObjectId,
			ref: 'YearLevel',
		},
		classes: [{
			type: Schema.Types.ObjectId,
			ref: 'Classes'
		}],
		type: {
			type: String,
			enum: ['mandatory', 'complementary', 'elective'],
			required: [true, "Please add a Subject type"],
		},
		employees: [
			{
				type: Schema.Types.ObjectId,
				ref: "Users",
				required: true,
			},
		],
		status: {
			type: Boolean,
			default: true,
		},
		workload: {
			type: Number,
			required: [true, "Workload is required"],
			min: 0
		},
		credits: {
			type: Number,
			required: [true, "Credits is required"],
			min: 0
		},
		minGradeToPass: {
			type: Number,
			default: 6.0,
			min: 0,
			max: 10
		},
		description: String,
	},
	{ timestamps: true }
);

// SubjectSchema.index({ school: 1, code: 1 }, { unique: true });
SubjectSchema.index({ school: 1, academicYear: 1, yearLevel: 1, code: 1 }, { unique: true });

module.exports = mongoose.models.Subjects || mongoose.model('Subjects', SubjectSchema);