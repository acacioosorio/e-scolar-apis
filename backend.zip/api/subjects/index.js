// Subjects Router
// ./api/subjects/index.js

'use strict';

const express = require('express');
const controller = require('./subjects.controller');
const router = express.Router();
const passport = require('passport');
const { authorizeRoles, authorizeSubRoles } = require('../../middleware/auth');
const { auditCreate, auditUpdate, auditDelete } = require('../../middleware/audit.middleware');
const Subjects = require('./subjects.model');

// Subject management routes
router.get('/', passport.authenticate('jwt-user', { session: false }), 
    authorizeRoles('backoffice', 'school'), 
    authorizeSubRoles('admin', 'staff', 'teacher'), 
    controller.listSubjects
);

router.post('/', passport.authenticate('jwt-user', { session: false }), 
    authorizeRoles('backoffice', 'school'), 
    authorizeSubRoles('admin', 'staff'),
    auditCreate('Subjects', Subjects),
    controller.addSubject
);

router.put('/', passport.authenticate('jwt-user', { session: false }), 
    authorizeRoles('backoffice', 'school'), 
    authorizeSubRoles('admin', 'staff'),
    auditUpdate('Subjects', Subjects),
    controller.updateSubject
);

router.patch('/:id/status', passport.authenticate('jwt-user', { session: false }),
    auditUpdate('Subjects', Subjects),
    authorizeRoles('backoffice', 'school'),
    authorizeSubRoles('admin'),
    controller.updateSubjectStatus
);

router.delete('/:id', passport.authenticate('jwt-user', { session: false }), 
    authorizeRoles('backoffice', 'school'), 
    authorizeSubRoles('admin', 'staff'),
    auditDelete('Subjects', Subjects),
    controller.deleteSubject
);

module.exports = router;
